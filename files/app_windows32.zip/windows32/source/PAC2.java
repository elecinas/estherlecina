import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.effects.*; 
import ddf.minim.signals.*; 
import ddf.minim.spi.*; 
import ddf.minim.ugens.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class PAC2 extends PApplet {

//********** tots els recursos grafics pertanyen a https://www.freepik.es/home *****************//
//********** la música pertany a https://www.jamendo.com/artist/462666/free-songs ********************//
////«We wish you a merry Christmas simphony», by Akashic Records
//*********** efectes de so http://sonidosmp3gratis.com/ *************************//
///Tot lliure de drets :)

//Importamos la biblioteca Minim para poder trabajar con audio






//Importamos biblioteca controlP5

//********************************DECLARACIÓ DE VARIABLES*************************************//
//********************************DECLARACIÓ DE VARIABLES*************************************//
//********************************DECLARACIÓ DE VARIABLES*************************************//
//********************************DECLARACIÓ DE VARIABLES*************************************//


ControlP5 userinterface;//creamos las variables para diferentes botones
ControlP5 botonesconfiguracion;

Minim myMinim;//variable para la biblioteca Minim
AudioPlayer music;//variable reproductor de audio
AudioPlayer pushbutton;//variable sonido botón
AudioPlayer bip1;//rebote de pelota 1
AudioPlayer bip2;//rebote de pelota 2

Clock clock;//creamos variables de las clases clock y timer
Timer timerDown;

int frame;//en esta variable sabremos en qué página esta el programa

final int ANIMACION_INICIO = 0;//Constantes para la variable frame
final int MENU_PRINCIPAL = 1;
final int MENU_CONFIGURACION = 2;
final int JUEGO = 3;
final int DESPEDIDA = 4;
final int VICTORIA = 5;
final int GAMEOVER = 6;

controlP5.Button bconfiguracion;//almacenamos los botones del menu principal
controlP5.Button bjugar;
controlP5.Button bsalir;

controlP5.Button binicio;//almacenamos el botón volver al menú principal

controlP5.Button bmusic;//almacenamos los botones de configuracion
controlP5.Button bfondo;

boolean displayprincipal = false;// estos booleanos servirán para mostrar y ocultar los botones según la pantalla
boolean displayinicio = false;

float secondsf;// variables para controlar el reloj de juego
int min;
int hor;

//Ahora declaro las variables para las imágenes de fondo
PImage fondo_inicio;
PImage fondo_config;
PImage fondo_fin;
PImage fondo_juego;

//Variables para las imagenes de los botones configuracion
PImage activeMusic;
PImage activeImage;
PImage defaultMusic;
PImage defaultImage;
PImage overMusic;
PImage overImage;

//Variables para las imagenes de los botones menu principal
PImage activeExit;
PImage defaultExit;
PImage overExit;
PImage activePlaygame;
PImage defaultPlaygame;
PImage overPlaygame;
PImage activeSettings;
PImage defaultSettings;
PImage overSettings;

//Variable para la imagen de volver a incio
PImage bhome;

//Cargo fuentes
PFont font1;
PFont fontNad;

//******variables ARKANOID*****//

boolean comencem; //(amb valor true o false, per comen ̧car el joc). float x; //posici x de la bola
float y; //posicio y de la bola
float x;
float vx; //component x de la velocitat de la bola
float vy; //component y de la velocitat de la bola int diametre; //diàmetre de la bola
int midapala; //longitud de la barra mòbil
boolean bloc1;//booleans per saber si els blocs del joc estan eliminats o no
boolean bloc2;
boolean bloc3;
int level;//nivel de juego
int lives;//cantidad de vidas disponibles
boolean gameover;

PImage bloc1img;
PImage bloc2img;
PImage bloc3img;
PImage palaimg;


//********************************INICIALITZEM LES VARIABLES*************************************//
//********************************INICIALITZEM LES VARIABLES*************************************//
//********************************INICIALITZEM LES VARIABLES*************************************//
//********************************INICIALITZEM LES VARIABLES*************************************//

public void setup()
{
  
  frameRate (20);

  font1 = loadFont("Oswald-Regular-110.vlw");//cargamos fuentes
  fontNad = loadFont ("HennyPenny-Regular-150.vlw");

  bhome = loadImage ("home.png");//cargamos la imagen de volver a inicio

  activeMusic = loadImage ("bactive_music.png");//cargamos las imágenes de los botones configuracion
  activeImage = loadImage ("bactive_image.png");
  defaultMusic = loadImage ("bdefault_music.png");
  defaultImage = loadImage ("bdefault_image.png");
  overMusic = loadImage ("bover_music.png");
  overImage = loadImage ("bover_image.png");

  activeExit = loadImage ("bactive_exit.png");//cargamos las imágenes de los botones principales;
  defaultExit = loadImage ("bdefault_exit.png");
  overExit = loadImage ("bover_exit.png");
  activePlaygame = loadImage ("bactive_playgame.png");//cargamos las imágenes de los botones principales;
  defaultPlaygame = loadImage ("bdefault_playgame.png");
  overPlaygame = loadImage ("bover_playgame.png");
  activeSettings = loadImage ("bactive_settings.png");//cargamos las imágenes de los botones principales;
  defaultSettings = loadImage ("bdefault_settings.png");
  overSettings = loadImage ("bover_settings.png");

  myMinim = new Minim(this);//inicializamos la variable Minim
  music = myMinim.loadFile("xmas1.mp3");//cargamos la canción navideña
  pushbutton = myMinim.loadFile("press_button.mp3");//cargamos el sonido de apretar botón
  bip1 = myMinim.loadFile("bip1.mp3");//cargamos el sonido rebote1
  bip2 = myMinim.loadFile("bip2.mp3");//cargamos el sonido rebote2
  music.loop();//ponemos la canción navideña a sonar eternamente...

  userinterface = new ControlP5 (this);//colocamos la biblioteca en la variable
  userinterface.setBroadcast(false);//desativamos para que no se ejecuten los botones
  botonesconfiguracion= new ControlP5 (this); //colocamos la biblioteca en la variable del menú
  botonesconfiguracion.setBroadcast(false);//desativamos para que no se ejecuten los botones

  clock = new Clock();
  timerDown = new Timer();
  timerDown.setPoints (6000, 1000);//establecemos los límites del contador

  bconfiguracion = userinterface.addButton ("configuracion", 1, (width/2)-195, 124, 390, 104)//almacenamos los botones en sus variables
    .setImages(defaultSettings, overSettings, activeSettings);
  bjugar = userinterface.addButton ("juego", 2, (width/2)-195, 248, 390, 104)
    .setImages(defaultPlaygame, overPlaygame, activePlaygame);
  bsalir = userinterface.addButton ("salir", 3, (width/2)-195, 372, 390, 104)
    .setImages(defaultExit, overExit, activeExit);

  binicio = userinterface.addButton ("inicio", 4, 40, 520, 40, 40)//boton de volver a inicio
    .setImage (bhome);

  userinterface.setBroadcast(true);//activamos para que se ejecuten los botones

  bmusic = botonesconfiguracion.addButton ("musica", 5, (width/2)-195, 180, 390, 104)//botones de menu configuracion
    .setImages(defaultMusic, overMusic, activeMusic);
  bfondo = botonesconfiguracion.addButton ("fondo", 6, (width/2)-195, 324, 390, 104)
    .setImages(defaultImage, overImage, activeImage);
  botonesconfiguracion.setVisible(false);//ocultamos los botones de configuracion (a la manera de los apuntes :P)

  botonesconfiguracion.setBroadcast(true);//activamos para que se ejecuten los botones


  frame = 0;//situamos el programa en la primera página

  secondsf = 0.0f;//ponemos el tiempo a cero
  min = 0;
  hor = 0;

  //asigno las imagenes de fondo
  fondo_inicio = loadImage ("fondo_inicio.jpg");
  fondo_config = loadImage ("fondo_config.jpg");
  fondo_fin = loadImage ("fondo_fin.jpg");
  fondo_juego = loadImage ("fondo_juego.jpg");

  //**************Inicialització ARKANOID****************//

  x = 110;//inicialitzem la posició de la bola
  y = 190;
  vx = random(7, 9); // vx i vy son les coordenades de la velocitat.
  vy = random(7, 9); //Random dona un valor aleatori entre els valors proposats
  midapala = 120; // Mida de la barra mobil 
  comencem = false;//el boolea comença com a fals
  bloc1 = true;//al principi tots els blocs existeixen
  bloc2 = true;
  bloc3 = true;
  level = 1;//empezamos en nivel 1
  lives = 3;//tenemos 3 vidas
  gameover = false;//aún no ha acabado el juego

  bloc1img = loadImage ("bloc1.png");
  bloc2img = loadImage ("bloc2.png");
  bloc3img = loadImage ("bloc3.png");
  palaimg = loadImage ("pala.png");
}

//********************************BUCLE DRAW*************************************//
//********************************BUCLE DRAW*************************************//
//********************************BUCLE DRAW*************************************//
//********************************BUCLE DRAW*************************************//

public void draw()
{
  background (190, 195, 210);
  textSize(15);
  hideButtonPrincipal();//amaguem els botons del menu principal
  hideButtonInicio();//amaguem el boto de tornar a inici

  switch (frame) {//amb aquest switch anem a la plana de programa que toca
  case 0:
    pantallaInicio();
    break;
  case MENU_PRINCIPAL:
    menuPrincipal ();
    break;
  case MENU_CONFIGURACION:
    menuConfiguracion ();
    break;
  case JUEGO:
    menuJuego ();
    if (comencem == true) {//si el juego está activo movemos la bola
      movimentBola ();
    }
    break;
  case DESPEDIDA:
    despedida ();
    break;
  case VICTORIA:
    victoria();
    break;
  case GAMEOVER:
    gameover();
    break;
  }
}

//********************************FUNCIONES AUXILIARES*************************************//
//********************************FUNCIONES AUXILIARES*************************************//
//********************************FUNCIONES AUXILIARES*************************************//
//********************************FUNCIONES AUXILIARES*************************************//


public void hideButtonPrincipal() {//funcion que enseña/esconde el menu principal
  if (displayprincipal == false) {
    bconfiguracion.hide();
    bjugar.hide();
    bsalir.hide();
  } else {
    bconfiguracion.show();
    bjugar.show();
    bsalir.show();
  }
}

public void hideButtonInicio() {//funcion que enseña/esconde el boton inicio
  if (displayinicio == false) {
    binicio.hide();
  } else {
    binicio.show();
  }
}



public void pantallaInicio() {
  clock.update();//ponemos el reloj en marcha
  timerDown.update(clock.getDeltaMillis());
  timerDown.start (true);//activamos el contador
  image (fondo_inicio, 0, 0);
  textFont(fontNad, 125);
  fill(190, 250, 250);
  text("Bon Nadal!", (width/2)-308, 240);
  textFont(font1, 60);
  fill(50, 152, 203);
  text ("Editorial Quico", 220, 410);
  fill(255, 255, 255);
  textSize (15);
  text ("Pantalla principal en: " + PApplet.parseInt(timerDown.getTimeSec()), 620, 550);
  if (timerDown.getFinish()) {//comprovamos que el temporizador ha acabado
    timerDown.reset();
    frame = MENU_PRINCIPAL;//saltamos a la página siguiente
  }
}

public void menuPrincipal () {
  secondsf = 0.0f;
  min = 0;
  hor = 0;
  displayinicio = false;//ocultamos el botón de volver
  displayprincipal = true;//enseñamos el menú principal
  botonesconfiguracion.setVisible(false);//ocultamos menu configuracion
  image (fondo_inicio, 0, 0);
  textSize (30);
  text ("Menu principal", width/2, height/2);
  textSize(15);
}

public void menuConfiguracion () {
  botonesconfiguracion.setVisible(true);
  displayinicio = true;
  displayprincipal = false;
  image (fondo_config, 0, 0);
}

public void menuJuego () {
  image (fondo_inicio, 0, 0);
  botonesconfiguracion.setVisible(false);
  displayinicio = true;
  displayprincipal = false;

  //**************************** INICIO CÓDIGO JUEGO (ARKANOID)*************************************//

  noStroke ();
  fill (150, 210, 230);
  //rect (mouseX-midapala/2, 460, midapala, 30);//creem la pala que segueixi al ratoli en la posicio de les Y
  image (palaimg, mouseX-midapala/2, 460);
  ellipse (x, y, 15, 15);//creem la bola

  if (bloc1 == true) {
    image (bloc1img, 10, 30);
  }

  if (bloc2 == true) {
    image (bloc2img, (width/2)-125, 30);
  }

  if (bloc3 == true) {
    image (bloc3img, 540, 30);
  }

  //****************************** FIN CÓDIGO JUEGO (ARKANOID)*************************************//

  textSize(15);
  clock.update();
  secondsf += clock.getDeltaSec();//añadimos el tiempo que va pasando
  if (secondsf>=60.0f) {//contamos minutos
    min += 1;
    secondsf = 0.0f;
  }
  if (min>=60) {//contamos horas
    hor += 1;
    min =0;
  }

  text (hor+" : "+min+ " : "+PApplet.parseInt(secondsf), 700, 550);
  text ("level: "+level, 120, 550);
  text ("lives: "+lives, 200, 550);
  text ("Para iniciar y parar la bola, haz click en el ratón.", 320, 550);
}

public void victoria() {
  image (fondo_juego, 0, 0);
  botonesconfiguracion.setVisible(false);
  displayinicio = true;
  displayprincipal = false;

  textFont(fontNad, 90);
  fill(190, 250, 250);
  text ("VICTORY!", 170, 320);
  fill(255, 255, 255);
  textFont(font1, 15);  

  x = 110;//inicialitzem la posició de la bola
  y = 190;
  vx = random(7, 9); // vx i vy son les coordenades de la velocitat.
  vy = random(7, 9); //Random dona un valor aleatori entre els valors proposats
  midapala = 120; // Mida de la barra mobil 
  comencem = false;//el boolea comença com a fals
  bloc1 = true;//al principi tots els blocs existeixen
  bloc2 = true;
  bloc3 = true;
  level = 1;//empezamos en nivel 1
  lives = 3;//tenemos 3 vidas
  gameover = false;//aún no ha acabado el juego
}

public void gameover() {
  image (fondo_juego, 0, 0);
  botonesconfiguracion.setVisible(false);
  displayinicio = true;
  displayprincipal = false;

  textFont(fontNad, 90);
  fill(190, 250, 250);
  text ("GAME OVER", 110, 320);
  fill(255, 255, 255);
  textFont(font1, 15); 

  x = 110;//inicialitzem la posició de la bola
  y = 190;
  vx = random(7, 9); // vx i vy son les coordenades de la velocitat.
  vy = random(7, 9); //Random dona un valor aleatori entre els valors proposats
  midapala = 120; // Mida de la barra mobil 
  comencem = false;//el boolea comença com a fals
  bloc1 = true;//al principi tots els blocs existeixen
  bloc2 = true;
  bloc3 = true;
  level = 1;//empezamos en nivel 1
  lives = 3;//tenemos 3 vidas
  gameover = false;//aún no ha acabado el juego
}

public void despedida () {
  botonesconfiguracion.setVisible(false);
  displayinicio = false;
  displayprincipal = false;
  image (fondo_fin, 0, 0);
  textFont(fontNad, 90);
  fill(190, 250, 250);
  text ("Bones festes!", 130, 280);
  clock.update();
  timerDown.update(clock.getDeltaMillis());
  timerDown.start (true);
  fill(255, 255, 255);
  textFont(font1, 15);
  text ("Salimos en: " + PApplet.parseInt(timerDown.getTimeSec()), 660, 550);
  if (timerDown.getFinish()) {//cuenta atrás para salir
    exit();
  }
}

public void controlEvent(ControlEvent theEvent) {//capturar los eventos de los botones
  if (theEvent.isController()) {
    if (theEvent.controller().getName().equals("configuracion")) {
      pushbutton.rewind();
      pushbutton.play();
      pressedConfiguracion();
    }
    if (theEvent.controller().getName().equals("juego")) {
      pushbutton.rewind();
      pushbutton.play();
      pressedJuego();
    }
    if (theEvent.controller().getName().equals("salir")) {
      pushbutton.rewind();
      pushbutton.play();
      pressedSalir();
    }
    if (theEvent.controller().getName().equals("inicio")) {
      pushbutton.rewind();
      pushbutton.play();
      pressedInicio();
    }
  }
}
public void pressedConfiguracion() {//accionamos la página seleccionada
  secondsf = 0.0f;
  min = 0;
  hor = 0;
  frame = MENU_CONFIGURACION;
}
public void pressedJuego() {//accionamos la página seleccionada
  secondsf = 0.0f;
  min = 0;
  hor = 0;
  frame = JUEGO;
  comencem = false;
}
public void pressedSalir() {//accionamos la página seleccionada
  frame = DESPEDIDA;
}

public void pressedInicio() {//accionamos la página seleccionada
  secondsf = 0.0f;
  min = 0;
  hor = 0;
  frame = MENU_PRINCIPAL;
}


//************FUNCIONES ARKANOID****************//

public void mousePressed() {
  comencem = !comencem;//canvia de valor el boolea
}

public void movimentBola() {
  x = x + vx;//imprimeix velocitat a la bola
  y = y + vy;

  if ((x <= 0)|| (x >= width)) {//canvia de sentit quan toca la paret de l'esquerra o dreta
    vx = vx * -1;
  }

  if ((y >= height)) {//reinicia el joc perque hem perdut
    comencem = !comencem;
    lives -= 1;
    x = 110;
    y = 190;
    if (lives < 1) {
      frame = GAMEOVER;
    }
  }

  // si la bola xoca amb la pala, s’inverteix el sentit en l’eix x
  if ( y > height-130 && x > mouseX-midapala/2 && x < mouseX+midapala/2 ) {
    bip1.rewind();
    bip1.play();
    vy = vy * -1;
    y = y + vy;
  }

  //////Part del joc que comproba si els blocs estan i fan rebotar la bola
  ///// No es pot fer una funció SWITCH amb booleans, així que ho he fet amb IF

  if (bloc1 == true && bloc2 == true && bloc3 == true) {
    ///y<180, és quan la pilota està per sobre de l'alçada dels blocs més el marge
    ///(BLOC CENTRAL)si x>260 y x<540 y y<180, fora bloc2
    if (x>260 && x<540 && y<180) {
      bloc2 = false;
      sonaicanvisentit();
    } else if (x<260 && y<180) {///(BLOC ESQUERRE)si x<260 y y<180, fora bloc1
      bloc1 = false;
      sonaicanvisentit();
    } else if (x>540 && y<180) {///(BLOC DRET)si x>540 y y<180, fora bloc3
      bloc3 = false;
      sonaicanvisentit();
    }
  } else if (bloc1 == false && bloc2 == true && bloc3 == true) {
    /////(FALTA BLOC ESQUERRE) si x<260 y y<0, només rebota
    if (x<260 && y<0) {
      vy = vy * -1;
      y = y + vy;
    }
    /////(BLOC CENTRAL)si x>260 y x<540 y y<180, fora bloc2
    else if (x>260 && x<540 && y<180) {
      bloc2 = false;
      sonaicanvisentit();
    }
    ///(BLOC DRET)si x>540 y y<180, fora bloc3
    else if (x>540 && y<180) {
      bloc3 = false;
      sonaicanvisentit();
    }
  } else if (bloc1 == false && bloc2 == false && bloc3 == true) {
    /////han desaparegut el bloc esquerre i el central
    /////(FALTA BLOC ESQUERRE) si x<260 y y<0, només rebota
    if (x<260 && y<0) {
      vy = vy * -1;
      y = y + vy;
    }
    /////(FALTA BLOC CENTRAL)si x>260 y x<540 y y<0, només rebota
    else if (x>260 && x<540 && y<0) {
      vy = vy * -1;
      y = y + vy;
    }
    ///(BLOC DRET)si x>540 y y<180, fora bloc3
    else if (x>540 && y<180) {
      bloc3 = false;
      sonaicanvisentit();
    }
  } else if (bloc1 == false && bloc2 == false && bloc3 == false) {
    /////Han desaparegut tots els blocs. LEVEL UP!!
    /////(FALTA BLOC ESQUERRE) si x<260 y y<0, només rebota
    /////(FALTA BLOC CENTRAL)si x>260 y x<540 y y<0, només rebota
    ///(FALTA BLOC DRET)si x>540 y y<0, només rebota

    comencem = !comencem;
    x = 110;//inicialitzem la posició de la bola
    y = 190;
    vx += 12;
    vy += 12;
    level += 1;///LEVEL UP!
    bloc1 = true;
    bloc2 = true;
    bloc3 = true;
    if (level > 3) {
      frame = VICTORIA;
    }
  } else if (bloc1 == true && bloc2 == false && bloc3 == false) {
    /////han desaparegut el bloc central i dret
    ///(BLOC ESQUERRE)si x<260 y y<180, fora bloc1
    if (x<260 && y<180) {
      bloc1 = false;
      sonaicanvisentit();
    }
    /////(FALTA BLOC CENTRAL)si x>260 y x<540 y y<0, només rebota
    else if (x>260 && x<540 && y<0) {
      sonaicanvisentit();
    }
    ///(FALTA BLOC DRET)si x>540 y y<0, només rebota
    else if (x>540 && y<0) {
     sonaicanvisentit();
    }
  } else if (bloc1 == true && bloc2 == true && bloc3 == false) {
    /////ha desaparegut el bloc dret
    ///(BLOC ESQUERRE)si x<260 y y<180, fora bloc1
    if (x<260 && y<180) {
      bloc1 = false;
      sonaicanvisentit();
    }
    /////(BLOC CENTRAL)si x>260 y x<540 y y<180, fora bloc2
    else if (x>260 && x<540 && y<180) {
      bloc2 = false;
      sonaicanvisentit();
    }
    ///(FALTA BLOC DRET)si x>540 y y<0, només rebota
    else if (x>540 && y<0) {
      vy = vy * -1;
      y = y + vy;
    }
  } else if (bloc1 == true && bloc2 == false && bloc3 == true) {
    /////ha desaparegut el bloc central
    ///(BLOC ESQUERRE)si x<260 y y<180, fora bloc1
    if (x<260 && y<180) {
      bloc1 = false;
      sonaicanvisentit();
    }
    /////(FALTA BLOC CENTRAL)si x>260 y x<540 y y<0, només rebota
    else if (x>260 && x<540 && y<0) {
      vy = vy * -1;
      y = y + vy;
    }
    ///(BLOC DRET)si x>540 y y<180, fora bloc3
    else if (x>540 && y<180) {
      bloc3 = false;
     sonaicanvisentit();
    }
  } else if (bloc1 == false && bloc2 == true && bloc3 == false) {
    /////han desaparegut el bloc esquerre i el dret
    /////(FALTA BLOC ESQUERRE) si x<260 y y<0, només rebota
    if (x<260 && y<0) {
      vy = vy * -1;
      y = y + vy;
    }
    /////(BLOC CENTRAL)si x>260 y x<540 y y<180, fora bloc2
    else if (x>260 && x<540 && y<180) {
      bloc2 = false;
      sonaicanvisentit();
    }
    /////(FALTA BLOC DRET)si x>540 y y<0, només rebota
    else if (x>540 && y<0) {
      vy = vy * -1;
      y = y + vy;
    }
  }
}

public void sonaicanvisentit() {
  bip2.rewind();
  bip2.play();
  vy = vy * -1;
  y = y + vy;
}

//********** tots els recursos grafics pertanyen a https://www.freepik.es/home *****************//
//********** la música pertany a https://www.jamendo.com/artist/462666/free-songs ********************//
////«We wish you a merry Christmas simphony», by Akashic Records
//*********** efectes de so http://sonidosmp3gratis.com/ *************************//
///Tot lliure de drets :)


class Clock{
  
  int time_now;
  int time_old;
  int time_delta_millis;
  float time_delta_sec;
  
  Clock(){
    time_now = 0;
    time_old = 0;
    time_delta_millis = 0;
  }
  
  public void update(){
    time_now = millis();
    time_delta_millis = time_now - time_old;
    time_old = time_now;
    
    time_delta_sec = time_delta_millis / 1000.0f; 
  }
  
  public int getDeltaMillis(){
    return time_delta_millis;
  }
  
  public float getDeltaSec(){
    return time_delta_sec;
  }
}


class Timer {

  boolean up;
  int startPoint;
  int endPoint;
  boolean counting;
  int currentTime;

  Timer() {
    up = true;
    startPoint = 0;
    endPoint = 0;
    counting = false;
    currentTime = startPoint;
  }

  Timer (int sPoint, int ePoint) {
    startPoint = sPoint;
    endPoint = ePoint;

    if (startPoint <= endPoint) {
      up = true;
    } else {
      up = false;
    }

    currentTime = startPoint;
  }

  public void reset () {
    currentTime = startPoint;
    counting = false;
  }

  public void setPoints (int sPoint, int ePoint) {
    startPoint = sPoint;
    endPoint = ePoint;

    if (startPoint <= endPoint) {
      up = true;
    } else {
      up = false;
    }

    currentTime = startPoint;
  }

  public void update (int millis) {
    if (counting) {
      if (up) {
        currentTime += millis;
      } else {
        currentTime -= millis;
      }
    }
    if (getFinish()){
      counting = false;
    }
  }

  public void start (boolean onoff) {
    counting = onoff;
  }

  public int getTimeMillis () {
    return currentTime;
  }

  public float getTimeSec () {
    return (currentTime / 1000.0f);
  }

  public boolean getFinish() {
    if (up) {
      if (currentTime >= endPoint) {
        return true;
      } else {
        return false;
      }
    } else {
      if (currentTime <= endPoint) {
        return true;
      } else {
        return false;
      }
    }
  }
}
  public void settings() {  size(800, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "PAC2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
